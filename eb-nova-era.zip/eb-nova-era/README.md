# EB Nova Era — Assistente Jurídico

Interface de consulta jurídica para o jogo EB Nova Era (Roblox), com IA integrada.

---

## 🚀 Como fazer o deploy na Vercel (gratuito, ~5 minutos)

### Passo 1 — Crie uma conta na Vercel
Acesse [vercel.com](https://vercel.com) e registre-se com sua conta do GitHub (gratuito).

### Passo 2 — Suba o projeto no GitHub
1. Crie um repositório no [github.com](https://github.com) (pode ser privado)
2. Faça upload de todos os arquivos desta pasta:
   - `api/chat.js`
   - `public/index.html`
   - `vercel.json`

### Passo 3 — Importe no Vercel
1. No Vercel, clique em **"Add New Project"**
2. Conecte seu GitHub e selecione o repositório
3. Clique em **"Deploy"** (não precisa mudar nenhuma configuração)

### Passo 4 — Configure a API Key da Anthropic
1. No painel do projeto na Vercel, vá em **Settings → Environment Variables**
2. Adicione:
   - **Name:** `ANTHROPIC_API_KEY`
   - **Value:** sua chave (começa com `sk-ant-...`)
   - Marque os ambientes: Production, Preview, Development
3. Clique em **Save**
4. Vá em **Deployments** e clique em **Redeploy** no deploy mais recente

### Passo 5 — Compartilhe o link!
Sua URL será algo como: `https://eb-nova-era.vercel.app`  
Mande esse link para seus amigos — funciona em qualquer navegador, sem instalar nada.

---

## 🔑 Onde pegar a API Key da Anthropic

1. Acesse [console.anthropic.com](https://console.anthropic.com)
2. Crie uma conta (gratuito para começar)
3. Vá em **API Keys → Create Key**
4. Copie a chave gerada

---

## 💰 Custo

- **Vercel:** gratuito para projetos pessoais
- **Anthropic API:** pago por uso (~$0,003 por resposta com Claude Sonnet)
  - O plano gratuito inicial da Anthropic dá créditos suficientes para centenas de consultas

---

## 📁 Estrutura do projeto

```
eb-nova-era/
├── api/
│   └── chat.js          ← backend serverless (chama a API da Anthropic)
├── public/
│   └── index.html       ← frontend completo
├── vercel.json          ← configuração de rotas
└── README.md
```
