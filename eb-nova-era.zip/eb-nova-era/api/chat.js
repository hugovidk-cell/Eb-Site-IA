export default async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type');

  if (req.method === 'OPTIONS') return res.status(200).end();
  if (req.method !== 'POST') return res.status(405).json({ error: 'Method not allowed' });

  const { messages } = req.body;

  const LAWS = `
=== LEGISLAÇÃO DO EXÉRCITO BRASILEIRO NOVA ERA ===

Art. 1º. Esta Legislação rege todos os militares do Exército Brasileiro no Roblox. O descumprimento implica sanções do Código Penal Militar (CPM).
Parágrafo único. O desconhecimento das normas não justifica o descumprimento.
Art. 2º. Respeito é princípio primordial para todos, independente de hierarquia.
Art. 3°. Nenhum militar é obrigado a abrir mão de vida pessoal. Presença no batalhão é facultativa quando conectado.
Art. 4°. Patentes são concedidas por desempenho, comprometimento e mérito.
Art. 5°. Ao dirigir-se a superior, uso obrigatório dos pronomes correspondentes ao gênero informado. É proibida alteração no nome das patentes por gênero.
Art. 6°. PRAÇAS: linha de frente, mantém ordem, controla civis, apoia recrutamentos.
Art. 7°. GRADUADOS: supervisão dos praças, ponte entre oficialato e tropa, devem realizar alistamentos.
Art. 8°. OFICIALATO: liderança, comando, planejamento, execução de treinamentos, decisões estratégicas.
Art. 9°. Sanções descritas no Código Penal Militar.
Art. 10. Penas principais: Repreensão; Polichinelos (JJ's); Rebaixamento; Exílio; Exílio Permanente; Banimento.
Art. 11. Divisões, subdivisões, cursos e funções são equipes especializadas.
Art. 13. Divisões: BPE (Polícia), BFE (Forças Especiais), CIE (Inteligência), BAC (Ações de Comandos).
Art. 14. Subdivisões: STM (Superior Tribunal Militar), SGEx (Secretaria-Geral).
Art. 15. Cursos: ESA, CIGS, CIOpC, BIP, EsPCEx, AMAN.
Art. 16. Funções: INOVA (Investidores), JNEr (Jornal).
Art. 17. Cada militar pode ocupar no máximo: 1 posição no Oficialato, 1 em Divisão, 1 em Subdivisão, até 2 cursos.
Art. 18. Investidores e Jornal exigem abandono da carreira militar.
Art. 20. Identidade visual: fardamento e grupos devem seguir padrões institucionais.
Art. 33. Apenas oficiais, integrantes de batalhões e CIE podem aplicar punições.
Art. 35. Gramática correta é obrigatória exceto em canais informais (bate-papo, chat-booster).
Art. 36. Armamento é último recurso; priorizar resolução pacífica.
Art. 39. Algemas: proibido abuso. Permitido contra cheaters/raiders e por Graduados em recrutamentos.

=== CÓDIGO PENAL MILITAR (CPM) ===

Art. 1°. Define infrações disciplinares e punições.
Art. 2°. Aplica-se a todos os militares e civis, na ativa ou afastados.
Art. 4°. Direito ao duplo grau de jurisdição.
Art. 7°. INSTÂNCIAS:
  1ª Instância: STM — análise primária de exílios e rebaixamentos.
  2ª Instância: Estado-Maior — complexidade técnica.
  3ª Instância: Alto Comando — correção de erros graves, pode anular sentenças.
  4ª Instância: Supremo Tribunal Federal — votação solene das 3 primeiras instâncias.
  5ª Instância: Governo Federal — palavra final, inapelável.
  6ª Instância: Presidência — autoridade máxima, decisão soberana e irrecorrível.
Art. 10. Quem aplica o exílio NÃO pode julgar o réu.
Art. 11. Amigos íntimos, aliados e inimigos são impedidos de julgar.
Art. 17. Transgressão: ação/omissão que viola ética, deveres funcionais ou normas.
Art. 18. Sanções proporcionais à gravidade.
Art. 20. Classificação: TL (leves), TM (médias), TG (graves), TGV (gravíssimas).
Art. 22. AGRAVANTES: ambiente com civis; patente Aspirante+; múltiplas infrações; reincidência; usar estrutura da equipe; não cumprir sanção complementar.
Art. 23. ATENUANTES: réu primário; participação de menor importância; coação; confissão espontânea; sem prejuízo efetivo; colaboração com investigação.
Art. 24. Penas: Repreensão, Polichinelos, Rebaixamento, Exílio, Exílio Permanente, Banimento.
Art. 25. Repreensão = advertência verbal reservada. Pena para TL.
Art. 26. Polichinelos (JJ's) = pulos em número determinado. Pena para TM.
Art. 27. Rebaixamento = perda de patente (uma por vez, podendo ser múltiplos). Pena para TG.
Art. 28. Exílio = afastamento temporário. Pena para TG grave.
Art. 29. Exílio Permanente = afastamento definitivo. Pena para TGV.
Art. 30. Banimento = expulsão definitiva com proibição de retorno. Pena para TGV extremo.
Art. 31-34. Rebaixamento exige Aspirante+; Exílio exige 2º Tenente+; Exílio Permanente exige 1º Tenente+; Banimento exige Capitão+.

TRANSGRESSÕES LEVES (TL) — Pena: Repreensão:
TL1. Fardamento ou tonalidade de pele irregular.
TL2. Errar pronomes de tratamento.
TL3. Desempenho inadequado em serviço/instrução.
TL4. Abreviações ou erros gramaticais recorrentes em canais oficiais.
TL5. Solicitar treinamento ou formulário diretamente aos responsáveis.
TL6. Perguntas de cunho pessoal sem consentimento.
TL7. Confrontos armados consensuais fora das arenas.
TL8. Dançar dentro da instituição.

TRANSGRESSÕES MÉDIAS (TM) — Pena: Polichinelos:
TM1. Postura indecorosa na unidade.
TM2. Não exercer autoridade compatível com a patente.
TM3. Atrasar ou descumprir função.
TM4. Iniciar/participar de conflitos e discussões com outro militar.
TM5. Desrespeitar superior.
TM6. Desrespeitar serviço de patente inferior.
TM7. Reincidência em TL.

TRANSGRESSÕES GRAVES (TG) — Pena: Rebaixamento ou Exílio:
TG1. Usar documentos para vantagem indevida em avaliações.
TG2. Ocultar prints autorizados ou inserir informações falsas em relatórios.
TG3. Tratar superior com descaso ou comprometer sua autoridade.
TG4. Usar canais inadequados para denúncias contra militares.
TG5. Pedir ajuda a terceiros em avaliações administrativas.
TG6. Reincidência em TL e TM.
TG7. Ingressar em outra instituição enquanto alistado — traição.
TG8. Sair das comunidades do EB perdendo acesso.
TG9. Uso inadequado ou excessivo de algemas.
TG10. Solicitar aprovação em teste/exame de divisão.
TG11. Usar armamento como primeira alternativa, causando mortes sem justificativa.
TG12. Graduados sem 2 alistamentos em 30 dias.
TG13. Graduados em divisão/curso sem 2 alistamentos em 45 dias.
TG14. Estar na instituição sem comprovação de recrutamento oficial (accept-all).
TG15. Praticar accept-all ou recuse-all.
TG16. Troca de nome sem autorização.
TG17. Militares fazendo ações de patrulha sem autorização.
TG18. Abandonar jogo após punição física aplicada por batalhão.
TG19. Estar no quartel pós-descanso sem recrutar havendo civis na fila.
TG20. Relacionamento amoroso sem comunicar ao Estado-Maior; afeto no ambiente; seguir mesma carreira do cônjuge.
TG21. Oficial ausente sem motivo por 5 dias.
TG22. Estar em servidores Discord militares sem autorização do Governo Federal.
TG23. Exercer função de outra instituição indevidamente.
TG24. Usar aplicativos que burlem ações militares.
TG25. Reproduzir músicas impróprias no ambiente institucional.
TG26. Abuso de autoridade.

TRANSGRESSÕES GRAVÍSSIMAS (TGV) — Pena: Exílio Permanente ou Banimento:
TGV1. Vandalismo, tumulto ou flood nas instalações.
TGV2. Falso testemunho em processos judiciais.
TGV3. Falsificar ou modificar documentos internos.
TGV4. Xingamentos ou brincadeiras que atinjam a honra de militar.
TGV5. Apresentar provas falsificadas em processos.
TGV6. Atentar contra a moral de divisões/subdivisões por palavras/gestos ofensivos.
TGV7. Falsificar/usar ilicitamente patentes ou símbolos institucionais. → BANIMENTO.
TGV8. Usar contas falsas para atos ilícitos. → BANIMENTO.
TGV9. Desrespeitar, ameaçar ou desmoralizar militar, inclusive na presença de civis.
TGV10. Prejudicar a reputação do EB por condutas que geram descrédito.
TGV11. Assédio sexual ou moral. → BANIMENTO.
TGV12. Cyberbullying. → BANIMENTO.
TGV13. Obter conta de outro militar/civil. → BANIMENTO.
TGV14. Articular-se ou conspirar contra militar ou civil.
TGV15. Solicitar a militar que forneça dados de contas.
TGV16. Discriminação por raça, cor, religião, gênero, etc. → BANIMENTO.
TGV17. Publicar imagens de militares/civis para cyberbullying. → BANIMENTO.
TGV18. Propagar rumores ou informações falsas.
TGV19. Vazar informações sigilosas de divisões.
TGV20. Propor/receber benefícios ilícitos (corrupção).
TGV21. Reincidência em TG, TM ou TL.
TGV22. Nepotismo — promoções por amizade ou parentesco.
TGV23. Vazar conteúdo sigiloso de processos seletivos.
TGV24. Coação — compelir outrem a praticar atos.
TGV25. Divulgar informações sem autorização dos desenvolvedores.
TGV26. Participar de raids contra o EB sendo militar — terrorismo.
TGV26-A. Fundar/participar de instituições para promover desordem contra o EB.
TGV27. Vender, transferir ou trocar contas.
TGV28. Divulgar outras comunidades sem autorização. → BANIMENTO.
TGV29. Usar IA em atividades que exigem autoria própria.
TGV30. Atingir 3 exílios permanentes → BANIMENTO DEFINITIVO.
TGV31. Usar cargo para vantagem pessoal.
TGV32. Usar atribuições de terceiros para vantagem pessoal.
TGV33. Ataques institucionais, vandalismo em canais. → BANIMENTO.
TGV34. Abusar de comandos em exames/treinamentos sem permissão.

SANÇÕES COMPLEMENTARES (Art. 43):
I. Colaborar obrigatoriamente em curso específico.
II. Suspensão temporária de cursos (ESA, EsPCEx, AMAN).
III. Redução temporária do período de descanso.
`;

  const SYSTEM_PROMPT = `Você é o Assistente Jurídico Oficial do Exército Brasileiro Nova Era, um jogo de roleplay militar no Roblox. Seu papel é responder perguntas sobre as leis e o Código Penal Militar deste jogo.

Você tem acesso à legislação completa do jogo:
${LAWS}

INSTRUÇÕES DE COMPORTAMENTO:
- Responda sempre em português brasileiro, com linguagem formal mas acessível
- Ao citar artigos, use o formato: [Art. X - LEG] ou [Art. X - CPM]
- Crie contextos fictícios e exemplos práticos DENTRO DO UNIVERSO DO JOGO (Roblox/Discord) quando pedido
- Seja específico: mencione patentes, divisões, instâncias e transgressões pelo código (TL1, TG7, etc.)
- Quando criar cenários, descreva o personagem fictício, a situação, o processo disciplinar e a sentença
- Mantenha o tom militar e institucional
- Você conhece todos os artigos da legislação e do CPM do jogo
- Nunca confunda com o Exército Brasileiro real — isso é um jogo de Roblox
- Máximo 500 palavras por resposta, seja direto e objetivo`;

  try {
    const response = await fetch('https://api.anthropic.com/v1/messages', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'x-api-key': process.env.ANTHROPIC_API_KEY,
        'anthropic-version': '2023-06-01'
      },
      body: JSON.stringify({
        model: 'claude-sonnet-4-20250514',
        max_tokens: 1000,
        system: SYSTEM_PROMPT,
        messages
      })
    });

    const data = await response.json();

    if (!response.ok) {
      return res.status(response.status).json({ error: data.error?.message || 'Erro na API' });
    }

    const reply = data.content?.map(b => b.text || '').join('') || '';
    return res.status(200).json({ reply });

  } catch (err) {
    return res.status(500).json({ error: 'Erro interno do servidor' });
  }
}
